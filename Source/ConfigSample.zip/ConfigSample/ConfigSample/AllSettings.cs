﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConfigSample
{
    public class AllSettings
    {
        public string Setting1 { get; set; }

        public int Setting2 { get; set; }

        public float Setting3 { get; set; }

        public MySettings MySetting { get; set; }
    }
}
