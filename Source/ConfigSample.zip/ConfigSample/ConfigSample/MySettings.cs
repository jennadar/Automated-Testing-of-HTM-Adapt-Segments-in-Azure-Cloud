﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConfigSample
{
    public class MySettings
    {
        public int SomeInt { get; set;  }

        public string SomeString { get; set; }

        public float SomeFloat { get; set; }
    }
}
